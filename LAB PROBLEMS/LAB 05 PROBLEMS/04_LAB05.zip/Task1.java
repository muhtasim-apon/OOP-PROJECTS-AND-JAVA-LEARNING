public class Task1{
    public static void main(String[] args)
    {
    int arr[]=new int[5];
    arr[21]=100;
}
}