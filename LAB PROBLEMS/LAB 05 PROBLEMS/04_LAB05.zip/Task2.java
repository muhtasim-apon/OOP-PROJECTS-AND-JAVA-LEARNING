public class Task2 {
    public static void main(String[] args)
    {
        int a=1/0;
        System.out.println("The value of a is"+ a);
    }
}
