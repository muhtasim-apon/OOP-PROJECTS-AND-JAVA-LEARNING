package edu.lab.shapes.api;
public interface Shape {
    double area();
    double perimeter();
}
